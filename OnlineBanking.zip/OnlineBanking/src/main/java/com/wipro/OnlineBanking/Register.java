package com.wipro.OnlineBanking;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="Register")
public class Register {
	@Id
	private String userid;
	private String newpassword;
	private int newtransactionpin;
	@Indexed(unique=true)
	private long accno;
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getNewpassword() {
		return newpassword;
	}
	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}
	public long getAccno() {
		return accno;
	}
	public void setAccno(long accno) {
		this.accno = accno;
	}
	public int getNewtransactionpin() {
		return newtransactionpin;
	}
	public void setNewtransactionpin(int newtransactionpin) {
		this.newtransactionpin = newtransactionpin;
	}
	
	
}
