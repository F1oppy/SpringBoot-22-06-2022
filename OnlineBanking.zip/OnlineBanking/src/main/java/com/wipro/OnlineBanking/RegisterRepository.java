package com.wipro.OnlineBanking;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface RegisterRepository extends MongoRepository < Register, String >{

}
