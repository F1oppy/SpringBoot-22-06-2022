package com.wipro.OnlineBanking;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class RegisterServiceImplementation implements RegisterService{
	@Autowired
    private RegisterRepository registerRepository;

    @Override
    public Register createRegister(Register register) {
        return registerRepository.save(register);
    }

    @Override
    public Register updateRegister(Register register) {
        Optional < Register > registerDb = this.registerRepository.findById(register.getUserid());

        if (registerDb.isPresent()) {
            Register registerUpdate = registerDb.get();
            registerUpdate.setUserid(register.getUserid());
            registerUpdate.setAccno(register.getAccno());
            registerUpdate.setNewpassword(register.getNewpassword());
            registerUpdate.setNewtransactionpin(register.getNewtransactionpin());
            registerRepository.save(registerUpdate);
            return registerUpdate;
        } else {
            throw new ResourceNotFoundException("Record not found with id : " + register.getUserid());
        }
    }

    @Override
    public List < Register > getAllRegister() {
        return this.registerRepository.findAll();
    }

    @Override
    public Register getRegisterById(String userId) {

        Optional < Register > productDb = this.registerRepository.findById(userId);

        if (productDb.isPresent()) {
            return productDb.get();
        } 
        else {
            throw new ResourceNotFoundException("Record not found with id : " + userId);
        }
    }

}
