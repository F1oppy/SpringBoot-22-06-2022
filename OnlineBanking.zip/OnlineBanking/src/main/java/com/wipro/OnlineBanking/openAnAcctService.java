package com.wipro.OnlineBanking;


import java.util.List;

public interface openAnAcctService {
    
	openAnAcct createopenAnAcct(openAnAcct openAnAcct);
	

    List < openAnAcct > getAllopenAnAcct();
}